// window.addEventListener("scroll",function(){
//     let header = document.getElementById("navigator");
//     header.classList.toggle("sticky",window.scroll > 0);
// });

// alert('salam')